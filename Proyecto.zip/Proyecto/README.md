Landing: Es crear una pagina de inicio facil de usar y atractiva y de información. Oportunidad de inicio de sesión o una llamada a la acción(Puede ser pedir datos al usuario) 
